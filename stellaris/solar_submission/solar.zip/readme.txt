Solar System Simulation (Graphics Fall 2016)
-----------------------

Members
-------
Taylor Doell
Benjamin Kaiser

Key Assignments
---------------
T - Toggle Texture
W - Toggle Wireframe
L - Toggle Lighting
S - Toggle Smooth Shading
A - Toggle Animation Type
+ - Increase Animation Step
- - Decrease Animation Step
R - Increase Wireframe Resolution
D - Decrease Wireframe Resolution
Rotate Right (Right Arrow)
Rotate Left (Left Arrow)
Rotate Up (Up Arrow)
Rotate Down (Down Arrow)
Zoom In (Mouse Wheel up)
Zoom Out (Mouse Wheel down)

Panning may also be accomplished by clicking the left mouse button and dragging.
Commands may also be issued via a popup menu, accessed by clicking the right mouse button.
