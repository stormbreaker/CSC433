#ifndef TDBK_SUPER_H
#define TDBK_SUPER_H

#ifdef __APPLE__
	#include <GLUT/glut.h> // MacOS include
#elif (__linux__)
	#include <GL/glut.h> // LinuxOS include
#endif

#endif
